class A:
    def __init__(self, pb, pr, pv ):
        self.pb = pb
        self._pr = pr
        self.__pv = pv
        print("I am in A.")
    def show(self):
        print("I am show in A.")

class B(A):
    def __init__(self, pb, pr, pv):
        super().__init__(pb, pr, pv)
        print("I am in B.")
    def show(self):
        print("I am show in B.")

class C(A):
    def __init__(self, pb, pr, pv):
        super().__init__(pb, pr, pv)
        print("I am in C.")
    def show(self):
        print("I am show in C.")

class D(B,C):
    pass
    # def __init__(self):
    #     print("I am in D.")
    # def show(self):
    #     print("I am show in D.")


a = A(10, 20, 30)
b = B(10, 20, 30)
c = C(10, 20, 30)
d = D(10, 20, 30)

print(a.pb)
print(a._pr)
#print(a.__pv)

print(b.pb)
print(b._pr)
#print(b.__pv)
