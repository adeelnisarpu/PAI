print("Hello Word")
text = input("Enter Some thing")
print(text)