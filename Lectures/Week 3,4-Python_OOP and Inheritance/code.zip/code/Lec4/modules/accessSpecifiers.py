class Test:
    def __init__(self, pb, pr, pv):
        self.pb = pb
        self._pr = pr
        self.__pv = pv


t1 = Test(1,2,3)

print(t1.pb)
print(t1._pr)
#print(t1.__pv)
