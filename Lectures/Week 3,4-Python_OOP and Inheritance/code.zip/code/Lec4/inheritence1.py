class A:
    def __init__(self):
        print("I am in A.")
    def show(self):
        print("I am show in A.")

class B(A):
    def __init__(self):
        print("I am in B.")
    def show(self):
        print("I am show in B.")

class C(A):
    def __init__(self):
        print("I am in C.")
    def show(self):
        print("I am show in C.")

class D(B,C):
    pass
    # def __init__(self):
    #     print("I am in D.")
    # def show(self):
    #     print("I am show in D.")


#a = A()
#a.show()

d = D()
d.show()

print(D.__mro__)