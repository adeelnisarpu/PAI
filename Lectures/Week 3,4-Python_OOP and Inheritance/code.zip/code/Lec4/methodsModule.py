def show():
    print("Hi, I am in a different module.")

def sayHello():
    print("Hello There")