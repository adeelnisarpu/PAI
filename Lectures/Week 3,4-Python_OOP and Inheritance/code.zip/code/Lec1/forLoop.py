for i in range(0,5,2):
    print(i)