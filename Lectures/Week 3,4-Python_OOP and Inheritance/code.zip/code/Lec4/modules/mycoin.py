import coin

myCoin = coin.Coin("Head")
#print(myCoin.getCoinState())
#print(myCoin.coinState)

myCoin.performToss()
myCoin.__coinState = "Tail"
print(myCoin.getCoinState())
#print(myCoin.coinState)

myCoin.performToss()
#myCoin.coinState = "Tail"
myCoin.__coinState = "Tail"
print(myCoin.getCoinState())
print(myCoin.__coinState)

myCoin.performToss()
#myCoin.coinState = "Tail"
myCoin.__coinState = "Tail"
print(myCoin.getCoinState())
#print(myCoin.coinState)