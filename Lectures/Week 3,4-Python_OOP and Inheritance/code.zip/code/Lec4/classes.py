import person
import methodsModule as mm



def main():
    p1 = person.Person("Akram", 27, 170)
    print(p1.name)
    print(p1._age)
    #print(p1.__height)

    #p1.name = "Nisar"
    #print(p1)
    #print("1")
    #p1.printName()
    #p1.__init__()
    #print("2")
    #p1.printName()
    #print("3")
    #p1.print()

    #person.Person().printName()

    #mm.show()
    #mm.sayHello()


main()