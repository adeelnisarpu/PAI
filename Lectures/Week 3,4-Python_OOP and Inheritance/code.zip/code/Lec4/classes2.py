class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def getName(self):
        return self.name
    
    def getAge(self):
        return self.age

def main():
    p1 = Person("Ali", 32)
    print("Name of the Person: ", p1.getName())
    print("Age of the Person: ", p1.getAge())

main()