def printNegative(list):
  for i in list:
    if i < 0:
      print(i)

myList = [-1,-2,3,4,5,-7,-8]
printNegative(myList)