a = 20
if a == 10:
    print("Yes! a is 10")
elif a > 10:
    print("a is greater than 10")
else:
    print("I don't know. I am confused.")
