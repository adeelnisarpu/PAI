import person
import math

def main():
    p1 = person.Person("Ali", 32)
    print("Name of the Person: ", p1.getName())
    print("Age of the Person: ", p1.getAge())
    p1.show()

    person.Person("Aamna", 6).show()
    


main()