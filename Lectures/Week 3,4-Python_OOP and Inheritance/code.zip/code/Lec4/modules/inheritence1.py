class A:
    def __init__(self):
        print("I am in A.")
    def sayHello(self):
        print("Hello from A.")

class B(A):
    pass

class C(A):
    def __init__(self):
        print("I am in C.")

class D(B,C):
    pass

d = D()
