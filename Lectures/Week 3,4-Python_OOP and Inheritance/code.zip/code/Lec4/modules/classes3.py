import random
class Coin:
    def __init__(self, coinState):
        self.__coinState = coinState
    
    def performToss(self):
        temp = random.randint(0,1)
        if temp == 0:
            self.__coinState = "Tail"
        else:
            self.__coinState = "Head"
    
    def getCoinState(self):
        return self.__coinState

