num = int(input("Enter a number: "))
if num%2 == 1:
    print("Odd Number")
    print("Yes! really odd number.")
else:
    print("Even Number")