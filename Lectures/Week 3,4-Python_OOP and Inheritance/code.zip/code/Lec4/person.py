# class Person:
#     def __init__(self):
#         self.name = "adeel"
#         print("I am in init.")
#     def printName(self):
#         print(self.name)
#     def print(self):
#         print(" something")

class Person:
    def __init__(self, name, age, height):
        self.name = name #public
        self._age = age #protected
        self.__height = height #private

p1 = Person("Ali", 30, 175)
print(p1.name)
print(p1._age)
#print(p1.__height)
print(p1.Person.__height)

